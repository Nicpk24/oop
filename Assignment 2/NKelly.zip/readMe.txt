Installation/Use:
1. Open a command prompt and nagivate to the base directory of the Sort.jar file.
2. enter the command java -jar sort.jar -f(fileName).txt -t(compareType) -s(sortType).
	Where fileName is the name of the file to be sorted, located in the same folder. compareType is one of (v for volume, h for height, b for base area). sortType is one of (b for bubble sort, s for selection sort, i for insertion sort, m for merge sort, q for quick sort, z is for clear sort (returns a null list basically, so it's always sorted).
