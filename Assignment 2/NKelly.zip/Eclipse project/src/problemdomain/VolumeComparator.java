package problemdomain;

import java.util.Comparator;

import models.Polygon;

/**
 * This class defines how the comparator should function. The VolumeComparator
 * compares the volume of polygons.
 * 
 * @author Nic Kelly
 *
 */
public class VolumeComparator implements Comparator<Polygon> {

	/**
	 * This method compares the volumes of two objects
	 * 
	 * @return the difference between the volumes of the two objects
	 */
	@Override
	public int compare(Polygon o1, Polygon o2) {
		return (int) (o1.getVolume() - o2.getVolume());
	}

}
