package problemdomain.algorithms;

import java.util.Comparator;

import models.Polygon;

/**
 * This class defines how sorting works for quick sort
 * 
 * @author Nic Kelly
 *
 */
public class QuickSortController extends Controller {

	/**
	 * Sorts the list of items using merge sort.
	 * 
	 * @param items      to be sorted
	 * @param comparator defines how to compare objects
	 */
	@Override
	public void sort(Polygon[] items, Comparator<Polygon> compartator) {
		quicksort(items, compartator, 0, items.length - 1);
	}

	/**
	 * This is the quicksort function
	 * 
	 * @param items       to be sorted
	 * @param compartator defines how items are compared
	 * @param lowIndex    the lower bound of the functioon
	 * @param highIndex   the upper bound of the function
	 */
	private void quicksort(Polygon[] items, Comparator<Polygon> compartator, int lowIndex, int highIndex) {
		if (lowIndex < highIndex) {
			int pivot = partition(items, lowIndex, highIndex, compartator);

			quicksort(items, compartator, lowIndex, pivot - 1);
			quicksort(items, compartator, pivot + 1, highIndex);
		}
	}

	/**
	 * This is the partition function, it orders a list by selecting a pivot and
	 * ordering the elements accoring to that
	 * 
	 * @param items       to be sorted
	 * @param lowIndex    the lower bound of the function
	 * @param highIndex   the upper bound of the function
	 * @param compartator defines how to compare items
	 * @return partitionIndex this index defines where the pivot is after sorting
	 */
	private int partition(Polygon[] items, int lowIndex, int highIndex, Comparator<Polygon> compartator) {

		Polygon pivot = items[highIndex];

		int i = (lowIndex - 1);

		for (int j = lowIndex; j <= highIndex - 1; j++) {
			if (compartator.compare(items[j], pivot) > 0) {
				i++;
				Polygon temp = items[i];
				items[i] = items[j];
				items[j] = temp;
			}
		}
		Polygon temp = items[i + 1];
		items[i + 1] = items[highIndex];
		items[highIndex] = temp;
		return (i + 1);
	}
}