package problemdomain.algorithms;

import java.util.Comparator;

import models.Polygon;

/**
 * @author Nic Kelly
 *
 */
public class SelectionSortController extends Controller {

	/**
	 * Sorts the list of items using selection sort.
	 * 
	 * @param items      to be sorted
	 * @param comparator defines how to compare objects
	 */
	@Override
	public void sort(Polygon[] items, Comparator<Polygon> compartator) {
		int smallest = 0;
		for (int i = 0; i < items.length - 1; i++) {
			smallest = i;
			for (int j = i + 1; j < items.length; j++) {
				if (compartator.compare(items[j], items[smallest]) > 0) {
					smallest = j;
				}
			}
			if (smallest != i) {
				Polygon p = items[i];
				items[i] = items[smallest];
				items[smallest] = p;
			}
		}

	}

}
