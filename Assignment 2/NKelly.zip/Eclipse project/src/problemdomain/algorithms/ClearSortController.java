package problemdomain.algorithms;

import java.util.Comparator;

import models.Cone;
import models.Polygon;

/**
 * This class defines how the sort should work for clear sort
 * 
 * @author Nic Kelly
 *
 */
public class ClearSortController extends Controller {

	/**
	 * Sorts the list of items using clear sort.
	 * 
	 * @param items      to be sorted
	 * @param comparator defines how to compare objects
	 */
	@Override
	public void sort(Polygon[] items, Comparator<Polygon> compartator) {
		for (int i = 0; i < items.length; i++) {
			items[i] = (Polygon) new Cone("", 0, 0);
		}
	}

}
