package problemdomain.algorithms;

import java.util.Comparator;

import models.Polygon;

/**
 * This class defines how sorting should work for insertion sort
 * @author Nic Kelly
 *
 */
public class InsertionSortController extends Controller {
	
	/**
	 * Sorts the list of items using insertion sort.
	 * 
	 * @param items      to be sorted
	 * @param comparator defines how to compare objects
	 */
	@Override
	public void sort(Polygon[] items, Comparator<Polygon> comparator) {
		for (int i = 1; i < items.length; i++) {
	        Polygon current = items[i];
	        int j = i-1;
	        while ((j > -1) && (comparator.compare(items[j], current) < 0)) {
	            items[j+1] = items[j];
	            j--;
	        }
	        items[j+1] = current;
	    }
	}

}
