package problemdomain.algorithms;

import java.util.Comparator;

import models.Polygon;

/**
 * This class defines how the sort should work for bubble sort
 * 
 * @author Nic Kelly
 *
 */
public class BubbleSortController extends Controller {

	/**
	 * Sorts the list of items using bubble sort.
	 * 
	 * @param items      to be sorted
	 * @param comparator defines how to compare objects
	 */
	@Override
	public void sort(Polygon[] items, Comparator<Polygon> comparator) {

		Boolean sorted = false;

		while (!sorted) {
			sorted = true;
			for (int i = 0; i < items.length - 1; i++) {

				int diff = comparator.compare(items[i], items[i + 1]);

				if (diff < 0) {
					Polygon temp = items[i];
					items[i] = items[i + 1];
					items[i + 1] = temp;
					sorted = false;
				}

			}
		}
	}
}
