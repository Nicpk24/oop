package problemdomain.algorithms;

import java.util.Comparator;

import models.Polygon;

/**
 * This abstract controller class defines the base structure of a controller
 * type object.
 * 
 * @author Nic Kelly
 *
 */
public abstract class Controller {

	/**
	 * Sorts the list of items using the defined sort. This is abstract to reduce
	 * the overall complexity.
	 * 
	 * @param items      to be sorted
	 * @param comparator defines how to compare objects
	 */
	public abstract void sort(Polygon[] items, Comparator<Polygon> compartator);
}