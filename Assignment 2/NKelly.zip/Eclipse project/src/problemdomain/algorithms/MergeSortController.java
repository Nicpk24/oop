package problemdomain.algorithms;

import java.util.Comparator;

import models.Polygon;

/**
 * This class defines how sorting should work for merge sort
 * 
 * @author Nic Kelly
 *
 */
public class MergeSortController extends Controller {

	/**
	 * Sorts the list of items using merge sort.
	 * 
	 * @param items      to be sorted
	 * @param comparator defines how to compare objects
	 */
	@Override
	public void sort(Polygon[] items, Comparator<Polygon> compartator) {
		mergeSort(items, items.length, compartator);
	}

	/**
	 * This method defines how merge sort works.
	 * 
	 * @param items      to be sorted
	 * @param itemSize   the size of the item list
	 * @param comparator defines how to compare objects
	 */
	private void mergeSort(Polygon[] items, int itemSize, Comparator<Polygon> comparator) {
		if (itemSize < 2) {
			return;
		}
		int pivot = itemSize / 2;
		Polygon[] leftArray = new Polygon[pivot];
		Polygon[] rightArray = new Polygon[itemSize - pivot];

		for (int i = 0; i < pivot; i++) {
			leftArray[i] = items[i];
		}
		for (int i = pivot; i < itemSize; i++) {
			rightArray[i - pivot] = items[i];
		}
		mergeSort(leftArray, pivot, comparator);
		mergeSort(rightArray, itemSize - pivot, comparator);

		merge(items, leftArray, rightArray, pivot, itemSize - pivot, comparator);
	}

	/**
	 * Merges two lists into one list
	 * 
	 * @param items      the list to merge into
	 * @param leftArray  list to be merged
	 * @param rightArray list to be merged
	 * @param leftIndex  index of sorting
	 * @param rightIndex index of sorting
	 * @param comparator defined how to compare items
	 */
	public void merge(Polygon[] items, Polygon[] leftArray, Polygon[] rightArray, int leftIndex, int rightIndex,
			Comparator<Polygon> comparator) {

		int i = 0, j = 0, k = 0;
		while (i < leftIndex && j < rightIndex) {
			if (comparator.compare(leftArray[i], rightArray[j]) > 0) {
				items[k++] = leftArray[i++];
			} else {
				items[k++] = rightArray[j++];
			}
		}
		while (i < leftIndex) {
			items[k++] = leftArray[i++];
		}
		while (j < rightIndex) {
			items[k++] = rightArray[j++];
		}
	}
}
