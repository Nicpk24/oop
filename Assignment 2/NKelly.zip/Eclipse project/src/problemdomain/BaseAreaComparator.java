package problemdomain;

import java.util.Comparator;

import models.Polygon;

/**
 * This class defines how the comparator should function. The BaseAreaComparator
 * compares the base area of polygons.
 * 
 * @author Nic Kelly
 *
 */
public class BaseAreaComparator implements Comparator<Polygon> {

	/**
	 * This method compares the areas of two polygon objects
	 * 
	 * @return the difference between the area of the polygons.
	 */
	@Override
	public int compare(Polygon o1, Polygon o2) {
		return (int) (o1.getArea() - o2.getArea());
	}
}
