package problemdomain;

import java.util.Comparator;

import models.Polygon;

/**
 * This class defines how the comparator should function. The HeightComparator
 * compares the height of polygons.
 * 
 * @author Nic Kelly
 *
 */
public class HeightComparator implements Comparator<Polygon> {

	/**
	 * This method compared the heights of two polygons
	 * 
	 * @return the difference between the heights
	 */
	@Override
	public int compare(Polygon o1, Polygon o2) {
		return (int) (o1.getHeight() - o2.getHeight());
	}

}
