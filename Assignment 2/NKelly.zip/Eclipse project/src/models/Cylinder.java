package models;

/**
 * This is the class for a cylinder object.
 * 
 * @author Nic Kelly
 */
public class Cylinder extends Polygon {
	private double radius;

	/**
	 * This is the constructor for a cylinder.
	 * 
	 * @param title  of the cylinder
	 * @param height of the cylinder
	 * @param radius of the cylinder
	 */
	public Cylinder(String title, double height, double radius) {
		super(height, title);
		this.radius = radius;
	}

	/**
	 * getRadius()
	 * 
	 * @return the radius of the cylinder
	 */
	public double getRadius() {
		return radius;
	}

	/**
	 * getArea()
	 * 
	 * @return the area of the cylinder
	 */
	@Override
	public double getArea() {
		return Math.PI * Math.pow(this.radius, 2);
	}

	/**
	 * getVolume()
	 * 
	 * @return the volume of the cylinder
	 */
	@Override
	public double getVolume() {
		return Math.PI * Math.pow(this.radius, 2) * this.getHeight();
	}
}
