package models;

/**
 * This is the class for a cone object.
 * 
 * @author Nic Kelly
 */
public class Cone extends Polygon {
	private double radius;

	/**
	 * This is the constructor for a cone
	 * 
	 * @param height of the cone
	 * @param radius of the cone
	 */
	public Cone(String title, double height, double radius) {
		super(height, title);
		this.radius = radius;
	}

	/**
	 * getRadius()
	 * 
	 * @return the radius of the cone
	 */
	public double getRadius() {
		return radius;
	}

	/**
	 * getArea()
	 * 
	 * @return the area of the cone
	 */
	public double getArea() {
		return Math.PI * Math.pow(this.radius, 2);
	}

	/**
	 * getVolume()
	 * 
	 * @return the volume of the cone
	 */
	@Override
	public double getVolume() {
		return (1.0 / 3) * Math.PI * Math.pow(this.radius, 2) * this.getHeight();
	}
}
