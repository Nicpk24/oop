package models;

/**
 * This is the class for an octagonal prism object
 * 
 * @author Nic Kelly
 */
public class OctagonalPrism extends Prism {

	/**
	 * This is the constructor for an octagonal prism
	 * 
	 * @param title      of an octagonal prism
	 * @param height     of an octagonal prism
	 * @param edgeLength of an octagonal prism
	 */
	public OctagonalPrism(String title, double height, double edgeLength) {
		super(title, height, edgeLength);
	}

	/**
	 * getArea()
	 * 
	 * @return the area of the octagonal prism
	 */
	@Override
	public double getArea() {
		return 2 * (1 + Math.sqrt(2)) * Math.pow(this.getEdgeLength(), 2);
	}

	/**
	 * getVolume()
	 * 
	 * @return the volume of the octagonal prism
	 */
	@Override
	public double getVolume() {
		return 2 * (1 + Math.sqrt(2)) * Math.pow(this.getEdgeLength(), 2) * this.getHeight();
	}
}
