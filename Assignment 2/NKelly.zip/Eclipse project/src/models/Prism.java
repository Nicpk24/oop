package models;

/**
 * This is the prism class it's used to reduce complexity among the many prism
 * types.
 * 
 * @author Nic Kelly
 *
 */
public abstract class Prism extends Polygon {
	private double edgeLength;

	/**
	 * This is the constructor for a prism object
	 * 
	 * @param title      of the prism object
	 * @param height     of the prism object
	 * @param edgeLength of the prism object
	 */
	public Prism(String title, double height, double edgeLength) {
		super(height, title);
		this.edgeLength = edgeLength;
	}

	/**
	 * getEdgeLength()
	 * 
	 * @return the edgeLength of the prism
	 */
	public double getEdgeLength() {
		return edgeLength;
	}
}
