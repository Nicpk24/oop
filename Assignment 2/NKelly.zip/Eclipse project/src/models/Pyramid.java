package models;

/**
 * This is a class for a pyramid object
 * @author Nic Kelly
 *
 */
public class Pyramid extends Polygon{
	private double length;
	
	/**
	 * This is the constructor for a pyramid object
	 * @param title of a pyramid object
	 * @param height of a pyramid object
	 * @param length of a pyramid object
	 */
	public Pyramid(String title, double height, double length) {
		super(height, title);
		this.length = length;
	}
	
	/** getLength()
	 * @return the length of the pyramid
	 */
	public double getLength() {
		return length;
	}
	
	/** getArea()
	 * @return the area of the pyramid
	 */
	@Override
	public double getArea() {
		return Math.pow(length, 2);
	}
	
	/** getVolume()
	 * @return the volume of the pyramid
	 */
	@Override
	public double getVolume() {
		return (1.0/3) * Math.pow(length, 2) * this.getHeight();
	}
}
