package models;

/**
 * This class represents a triangular prism object
 * 
 * @author Nic Kelly
 *
 */
public class TriangularPrism extends Prism {

	/**
	 * This is the constructor for a triangular prism object
	 * 
	 * @param title      of a triangular prism
	 * @param height     of a triangular prism
	 * @param edgeLength of a triangular prism
	 */
	public TriangularPrism(String title, double height, double edgeLength) {
		super(title, height, edgeLength);
	}

	/**
	 * getArea()
	 * 
	 * @return the area of a triangular prism
	 */
	@Override
	public double getArea() {
		return (Math.pow(this.getEdgeLength(), 2) * Math.sqrt(3)) / (4);
	}

	/**
	 * getVolume()
	 * 
	 * @return the volume of the triangular prism
	 */
	@Override
	public double getVolume() {
		return (Math.pow(this.getEdgeLength(), 2) * Math.sqrt(3)) / (4) * this.getHeight();
	}
}
