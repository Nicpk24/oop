package models;

/**
 * This is the class that represents a square prism object
 * 
 * @author Nic Kelly
 *
 */
public class SquarePrism extends Prism {

	/**
	 * This is the constructor for a square prism object
	 * 
	 * @param title      of a square prism
	 * @param height     of a square prism
	 * @param edgeLength of a square prism
	 */
	public SquarePrism(String title, double height, double edgeLength) {
		super(title, height, edgeLength);
	}

	/**
	 * getArea()
	 * 
	 * @return the area of the square prism
	 */
	@Override
	public double getArea() {
		return Math.pow(this.getEdgeLength(), 2);
	}

	/**
	 * getVolume()
	 * 
	 * @return the volume of the square prism
	 */
	@Override
	public double getVolume() {
		return Math.pow(this.getEdgeLength(), 2) * this.getHeight();
	}
}
