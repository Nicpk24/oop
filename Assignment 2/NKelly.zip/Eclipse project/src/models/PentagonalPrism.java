package models;

/**
 * This is the class for a Pentagonal prism object
 * 
 * @author Nic Kelly
 */
public class PentagonalPrism extends Prism {

	/**
	 * This is the constructor for a pentagonal prism
	 * 
	 * @param title      of a pentagonal prism
	 * @param height     of a pentagonal prism
	 * @param edgeLength of a pentagonal prism
	 */
	public PentagonalPrism(String title, double height, double edgeLength) {
		super(title, height, edgeLength);
	}

	/**
	 * getArea()
	 * 
	 * @return the area of the pentagonal prism
	 */
	@Override
	public double getArea() {
		return (5 * Math.pow(this.getEdgeLength(), 2) * Math.tan(Math.toRadians(54.0))) / (4);
	}

	/**
	 * getVolume()
	 * 
	 * @return the volume of the pentagonal prism
	 */
	@Override
	public double getVolume() {
		return (5 * Math.pow(this.getEdgeLength(), 2) * Math.tan(Math.toRadians(54.0))) / (4) * this.getHeight();
	}
}
