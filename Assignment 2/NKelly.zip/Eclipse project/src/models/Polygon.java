package models;

/**
 * This is the abstract class that represents a 3D polygon.
 * 
 * @author Nic Kelly
 *
 */
public abstract class Polygon {
	private double height;
	private String title;

	/**
	 * This is the constructor for a polygon
	 * 
	 * @param height of the polygon
	 * @param title  of the polygon
	 */
	public Polygon(double height, String title) {
		this.height = height;
		this.title = title;
	}

	/**
	 * getHeight()
	 * 
	 * @return the height of the polygon
	 */
	public double getHeight() {
		return height;
	}

	/**
	 * getTitle()
	 * 
	 * @return the title of the polygon
	 */
	public String getTitle() {
		return title;
	}

	public abstract double getArea(); // gets the area of the shape

	public abstract double getVolume(); // gets the volume of the shape
}
