package application;

import models.Polygon;
import problemdomain.*;
import problemdomain.algorithms.*;

/**
 * This is the main class for the sorting application.
 * 
 * @author Nic Kelly
 *
 */
public class AppDriver {
	/**
	 * This is the main method for the sorting application
	 * 
	 * @param arga these arguments are in the format "-f(fileName).txt
	 *             -t(compareType) -s(sortType)". compare type can be one of (v for
	 *             volume, h for height, b for base area). sort type can be one of
	 *             (b for bubble sort, s for selection sort, i for insertion sort, m
	 *             for merge sort, q for quick sort, z is for clear sort).
	 */
	public static void main(String[] args) {
		String arguments = args[0] + ":" + args[1] + ":" + args[2] + ":";
		arguments = arguments.toLowerCase();

		if (arguments.contains("-f") && arguments.contains("-t") && arguments.contains("-s")) { // ensure all flags are
																								// present in arguments
//			System.out.println("ARGUMENTS: " + arguments);

			int fileStart = arguments.indexOf("-f") + 2;
			int fileEnd = arguments.indexOf(":", fileStart);
			String fileName = arguments.substring(fileStart, fileEnd);
//			System.out.println("FILENAME: " + fileName);

			int typeStart = arguments.indexOf("-t") + 2;
			int typeEnd = arguments.indexOf(":", typeStart);
			String compareType = arguments.substring(typeStart, typeEnd);
//			System.out.println("COMPARETYPE: " + compareType);

			int sortStart = arguments.indexOf("-s") + 2;
			int sortEnd = arguments.indexOf(":", sortStart);
			String sortType = arguments.substring(sortStart, sortEnd);
//			System.out.println("SORTTYPE: " + sortType);

			ShapeManager m = new ShapeManager(fileName); // handles creating the list of objects
			Polygon[] list = m.getList();

			Controller b = null;

			System.out.print("Sorting " + fileName);

			switch (sortType) {
			case "b":
				b = new BubbleSortController();
				System.out.print(" using Bubble sort");
				break;
			case "s":
				b = new SelectionSortController();
				System.out.print(" using Selection sort");
				break;
			case "i":
				b = new InsertionSortController();
				System.out.print(" using Insertion sort");
				break;
			case "m":
				b = new MergeSortController();
				System.out.print(" using Merge sort");
				break;
			case "q":
				b = new QuickSortController();
				System.out.print(" using Quick sort");
				break;
			case "z":
				b = new ClearSortController();
				System.out.print(" using Clear sort");
				break;
			default:
				b = new QuickSortController();
				System.out.print(" using a default of Quick sort");
				break;
			}

			System.out.print(" comparing ");

			long startTime = System.currentTimeMillis();

			switch (compareType) {
			case "v":
				System.out.print("volume.\n");
				System.out.println("Sorting started at " + String.valueOf(startTime) + "ms.");
				b.sort(list, new VolumeComparator());
				break;
			case "h":
				System.out.print("height.\n");
				System.out.println("Sorting started at " + String.valueOf(startTime) + "ms.");
				b.sort(list, new HeightComparator());
				break;
			case "a":
				System.out.print("base area.\n");
				b.sort(list, new BaseAreaComparator());
				System.out.println("Sorting started at " + String.valueOf(startTime) + "ms.");
			default:
				System.out.println("Sort not chosen?");
				b = null;
				break;
			}

			long endTime = System.currentTimeMillis();
			System.out.println("Sortig ended at " + String.valueOf(endTime) + "ms.");

			System.out.println("Sorting finished in " + String.valueOf((endTime - startTime)) + "ms.");

//			for (int i = 0; i < list.length; i++) {
//				Polygon p = list[i];
//				String message = String.format("%-10s, x: %15f, Area: %20f, Volume: %25f", p.getTitle(), p.getHeight(),
//						p.getArea(), p.getVolume());
//				System.out.println(message);
//			}

		} else {
			System.out.println("Arguments not found!");
		}

	}
}
