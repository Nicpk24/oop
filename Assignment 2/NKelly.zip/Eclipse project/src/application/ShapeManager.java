package application;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.StringTokenizer;

import models.Polygon;

/**
 * This is the shape manager class, it handles parsing though the chosen file
 * and creating the list of objects to sort
 * 
 * @author Nic Kelly
 *
 */
public class ShapeManager {
	private Polygon[] list;
	private String fileName;

	/**
	 * This is the constructor for the shape manager. The call to generate the list
	 * happens when a shape manager object is created.
	 * 
	 * @param fileName the name of the file to sort.
	 */
	public ShapeManager(String fileName) {
		this.fileName = fileName;
		generateList();
	}

	/**
	 * getList()
	 * 
	 * @return the list of objects parsed by the shape manager.
	 */
	public Polygon[] getList() {
		return list;
	}

	/**
	 * This function generates the list of objects by parsing through the file
	 * referenced by the ShapeManager object.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void generateList() {
		BufferedReader in = null;
		try {
			in = new BufferedReader(new FileReader(this.fileName));

			String line = in.readLine();
			StringTokenizer st = new StringTokenizer(line, " ");

			this.list = new Polygon[Integer.valueOf((String) st.nextElement())];

			int i = 0;

			while (st.hasMoreElements()) {
				String className = "models." + st.nextToken();
				Class c = Class.forName(className);

				Class paramTypes[] = new Class[3];
				paramTypes[0] = String.class;
				paramTypes[1] = Double.TYPE;
				paramTypes[2] = Double.TYPE;

				Constructor ct = c.getConstructor(paramTypes);
				String x = st.nextToken();
				String y = st.nextToken();
				Object argList[] = new Object[3];

				argList[0] = className.substring(7);
				argList[1] = Double.valueOf(x);
				argList[2] = Double.valueOf(y);

				Object o = ct.newInstance(argList);

				list[i] = (Polygon) o;
				i++;
			}

			in.close();

		} catch (IOException | ClassNotFoundException | NoSuchMethodException | SecurityException
				| InstantiationException | IllegalAccessException | IllegalArgumentException
				| InvocationTargetException e) {
			try {
				in.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
	}
}