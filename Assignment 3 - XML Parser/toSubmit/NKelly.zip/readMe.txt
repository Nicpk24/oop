How to install and use the XML parser program.

1. Open command prompt and navigate to the jar file.
2. type "java -jar Parser.jar (file name)" where (file name) is the name of the file that you wish to be parsed.
3. Read output.