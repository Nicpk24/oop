Open the ClientDriver.jar file. Enter the desired username, host, and port and the client will connect to the server.
Click the find game button ask to be placed into a game.
Click the Connect button to change username, and connect to a server again.
Clicking the exit button while connected will disconnect from the server.
Clicking the exit button while not connected will close the client.
Typing into the textfield at the bottom of the gui and pressing the send button will message the server.