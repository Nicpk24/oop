Open the ServerDriver.jar file and input the port. 
This will start the server and should be done before a Client tries to connect