package contracts;

import java.io.Serializable;

/**
 * The abstract data type for a binary search tree
 * 
 * @author Nic Kelly
 *
 */
public interface BSTreeADT<E> extends Serializable {
	/**
	 * Adds an element to the binary search tree
	 * 
	 * Pre-condition: The element is of the same type as the tree
	 * Post-condition: The element is placed in order on the binary tree
	 * 
	 * @param data Element data to add.
	 * @return true if element was added
	 */
	public boolean add(E data);

	/**
	 * Checks if a node has a left child
	 * 
	 * Pre-condition: Node to check is part of a binary search tree
	 * Post-condition: Tree is unchanged and a boolean is returned
	 * 
	 * @param node the node to check
	 * @return true if the tree has a left child
	 */
	public boolean hasLeftChild(BSTNodeADT<E> node);

	/**
	 * Checks if a node has a right child
	 * 
	 * Pre-condition: Node to check is part of a binary search tree
	 * Post-condition: Tree is unchanged and a boolean is returned
	 * 
	 * @param node the node to check
	 * @return true if the tree has a left child
	 */
	public boolean hasRightChild();

	/**
	 * Checks if the node is a leaf
	 * 
	 * Pre-condition: Node to check is part of a binary search tree
	 * Post-condition: Tree is unchanged and a boolean is returned
	 * 
	 * @param node to check
	 * @return true if the node is a leaf
	 */
	public boolean isLeaf(BSTNodeADT<E> node);

	public void getHeight();

	/**
	 * Gets the root of the tree
	 * 
	 * Pre-condition: None
	 * Post-condition: The root of the binary search tree is returned
	 * 
	 * @return the root node of tree
	 */
	public BSTNodeADT<E> getRoot();

	/**
	 * Gets the size of the tree
	 * 
	 * Pre-condition: None
	 * Post-condition: The size is represented accurately
	 * 
	 * @return the size of the tree
	 */
	public int size();

	/**
	 * Does the tree have any nodes?
	 * 
	 * Pre-condition: None
	 * Post-condition: A boolean is returned
	 * 
	 * @return true if the tree has nodes
	 */
	public boolean isEmpty();

	/**
	 * Clears the tree and garbage collect
	 * 
	 * Pre-condition: The list has been made
	 * Post-condition: The list contains no reference to any data which will be collected by the garbage collector
	 */
	public void clear();

	/**
	 * Does the tree contain a specified node
	 * 
	 * Pre-condition: None
	 * Post-condition: A boolean is returned
	 * 
	 * @param node to check if is in tree
	 * @return true if the node is in the tree
	 */
	public boolean contains(BSTNodeADT<E> node);

	/**
	 * Searches the list for a specified node and returns it
	 * 
	 * Pre-condition: None
	 * Post-condition: The tree is not changed and a boolen is returned
	 * 
	 * @param node to check if is in tree
	 * @return node if it is in the tree
	 */
	public BSTNodeADT<E> search(BSTNodeADT<E> node);

	/**
	 * Returns an in-order iterator
	 * 
	 * Pre-condition: None
	 * Post-condition: An in-order iterator of the elements in the tree is returned.
	 * 
	 * @return iterator instance
	 */
	public Iterator<E> iterator();
}
