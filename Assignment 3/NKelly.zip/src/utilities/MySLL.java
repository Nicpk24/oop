package utilities;

/**
 * MySLL is a singly linked list.
 * @author Nic Kelly
 */
public class MySLL<E> implements ListADT {
	private MySLLNode head;
	private int size;

	/**
	 * Create an empty singly linked list
	 */
	public MySLL() {
		head = null;
		size = 0;
	}

	@Override
	public int size() {
		return size;
	}

	@Override
	public void clear() {
		head = null;
		size = 0;
	}

	@Override
	public boolean add(int index, Object toAdd) throws NullPointerException, IndexOutOfBoundsException {
		if (index < 0 || index > size) {
			throw new IndexOutOfBoundsException();
		}
		MySLLNode<Object> newNode = new MySLLNode<Object>(toAdd);
		if (index == 0) {
			newNode.setNext(head);
			newNode.setData(toAdd);
		} else {
			MySLLNode<Object> node = head;
			for (int i = 0; i < size; i++) {
				if (i == (index - 1)) {
					MySLLNode<Object> temp = node.getNext();
					node.setNext(newNode);
					MySLLNode<Object> next = node.getNext();
					next.setNext(temp);
				}
				node = node.getNext();
			}
		}
		size++;
		return true;
	}

	@Override
	public boolean add(Object toAdd) throws NullPointerException, IndexOutOfBoundsException {
		MySLLNode<Object> newNode = new MySLLNode<Object>(toAdd);
		newNode.setNext(head);
		head = newNode;
		size++;
		return true;
	}

	@Override
	public boolean addAll(ListADT toAdd) throws NullPointerException {

		for (int i = 0; i < toAdd.size(); i++) {
			this.add(toAdd.get(i));
		}

		return true;
	}

	@Override
	public Object get(int index) throws IndexOutOfBoundsException {
		if (index < 0 || index > (size - 1)) {
			throw new IndexOutOfBoundsException();
		}
		MySLLNode<Object> node = head;
		for (int i = 0; i < size; i++) {
			if (i == index) {
				return node.getData();
			}
			node = node.getNext();
		}
		return null;
	}

	@Override
	public Object remove(int index) throws IndexOutOfBoundsException {
		if (index < 0 || index > (size - 1)) {
			throw new IndexOutOfBoundsException();
		} else if (index == 0) {
			MySLLNode<Object> toDelete = head;
			head = head.getNext();
			toDelete.setNext(null);
		} else {
			MySLLNode<Object> node = head;
			for (int i = 0; i < size; i++) {
				if (i == (index - 1)) {
					MySLLNode<Object> previous = node;
					MySLLNode<Object> toDelete = node.getNext();
					previous.setNext(toDelete.getNext());
					toDelete.setNext(null);
				} else {
					node = node.getNext();
				}
			}
		}

		size--;

		return null;
	}

	@Override
	public Object remove(Object toRemove) throws NullPointerException {
		return null;
	}

	@Override
	public Object set(int index, Object toChange) throws NullPointerException, IndexOutOfBoundsException {
		if (index < 0 || index > (size - 1)) {
			throw new IndexOutOfBoundsException();
		}
		MySLLNode<Object> node = head;
		MySLLNode<Object> returnNode = null;
		for (int i = 0; i < size; i++) {
			if (i == (index)) {
				returnNode = node;
				node.setData(toChange);
			}
			node = node.getNext();
		}

		return returnNode;
	}

	@Override
	public boolean isEmpty() {
		return (size <= 0);
	}

	@Override
	public boolean contains(Object toFind) throws NullPointerException {
		MySLLNode<Object> node = head;
		for (int i = 0; i < size; i++) {
			if (node.getData() == toFind) {
				return true;
			}
			node = node.getNext();
		}

		return false;
	}

	@Override
	public Object[] toArray(Object[] toHold) throws NullPointerException {

		MySLLNode<Object> node = head;

		for (int i = 0; i < size(); i++) {
			toHold[i] = node.getData();
			node = node.getNext();
		}

		return null;
	}

	@Override
	public Object[] toArray() {
		Object[] returnArr = new Object[size];

		MySLLNode<Object> node = head;

		for (int i = 0; i < size(); i++) {
			returnArr[i] = node.getData();
			node = node.getNext();
		}

		return returnArr;
	}

	@Override
	public Iterator<E> iterator() {
		return new MyArrayListIterator<E>((E[]) this.toArray(), size);
	}
}
