package utilities;

/**
 * MySLLNode is a model for a node in a linked list
 * @author Nic Kelly
 */
public class MySLLNode<E> {
	private E data;
	private MySLLNode next;
	
	/**
	 * Construct a new node with set data
	 * @param data to be set
	 */
	public MySLLNode(E data) {
		this.data = data;
	}
	/**
	 * @return the data
	 */
	public E getData() {
		return data;
	}
	/**
	 * @param data the data to set
	 */
	public void setData(E data) {
		this.data = data;
	}
	/**
	 * @return the next node
	 */
	public MySLLNode getNext() {
		return next;
	}
	/**
	 * @param next the node to set to next
	 */
	public void setNext(MySLLNode next) {
		this.next = next;
	}
}
