package test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import utilities.MyStack;

/**
 * @author Nic Kelly
 *
 */
class MyStackTests {
	MyStack stack;
	/**
	 * @throws java.lang.Exception
	 */
	@BeforeEach
	void setUp() throws Exception {
		stack = new MyStack();
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterEach
	void tearDown() throws Exception {
		stack = null;
	}

	@Test
	void testEmpty() {
		stack.push(1);
		stack.push(2);
		stack.pop();
		stack.pop();
		assertEquals(0, stack.size());
	}

	@Test
	void testPeek() {
		stack.push(1);
		assertEquals(1,  stack.peek());
		assertEquals(1,  stack.peek());
		assertEquals(1,  stack.peek());
		assertEquals(1,  stack.size());
	}
	
	@Test
	void testPop() {
		stack.push(1);
		stack.push(2);
		stack.push(3);
		stack.push(4);
		stack.push(5);
		assertEquals(5, stack.pop());
		assertEquals(4, stack.pop());
		assertEquals(3, stack.pop());
		assertEquals(2, stack.pop());
		assertEquals(1, stack.pop());
	}
	
	@Test
	void testPush() {
		stack.push(1);
		stack.push(2);
		stack.push(3);
		stack.push(4);
		stack.push(5);
		assertEquals(5, stack.size());
		assertEquals(5, stack.pop());
	}
	
	@Test
	void testSize() {
		stack.push(1);
		stack.push(2);
		stack.push(3);
		stack.push(4);
		stack.push(5);
		assertEquals(5, stack.size());
	}
}
