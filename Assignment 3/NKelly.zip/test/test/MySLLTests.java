package test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import utilities.Iterator;
import utilities.MyArrayList;
import utilities.MySLL;

class MySLLTests {
	private MySLL<String> list;

	@BeforeEach
	void setUp() throws Exception {
		list = new MySLL<>();
	}

	@AfterEach
	void tearDown() throws Exception {
		list.clear();
		list = null;
	}

	@Test
	void testAddAtIndex() {
		list.add("third");
		list.add("first");
		list.add(1, "second");
		assertEquals("first", list.get(0));
		assertEquals("second", list.get(1));
		assertEquals("third", list.get(2));
		assertEquals(3, list.size());
	}
	@Test
	void testAdd() {
		list.add("test");
		list.add("this");
		list.add("out");
		assertEquals(3, list.size());
	}
	@Test
	void testAddAll() {
		MyArrayList<Object> toAdd = new MyArrayList<>();
		toAdd.add("1");
		toAdd.add("2");
		toAdd.add("3");
		list.addAll(toAdd);
		list.add("4");
		list.add("5");
		list.add("6");
		assertEquals("6", list.get(0));
		assertEquals("5", list.get(1));
		assertEquals("4", list.get(2));
		assertEquals("3", list.get(3));
		assertEquals("2", list.get(4));
		assertEquals("1", list.get(5));
		assertEquals(6, list.size());
	}
	@Test
	void testClear() {
		list.add("1");
		list.add("2");
		list.add("3");
		assertEquals(3,  list.size());
		list.clear();
		assertEquals(0,  list.size());
	}
	@Test
	void testContains() {
		list.add("64");
		assertTrue(list.contains("64"));
	}
	@Test
	void testGet() {
		list.add("3");
		list.add("2");
		list.add("1");
		assertEquals("1", list.get(0));
		assertEquals("2", list.get(1));
		assertEquals("3", list.get(2));
		assertEquals(3,  list.size());
	}
	@Test
	void testIsEmpty() {
		list.add("1");
		assertFalse(list.isEmpty());
		list.clear();
		assertTrue(list.isEmpty());
	}
	@Test
	void testIterator() {
		list.add("3");
		list.add("2");
		list.add("1");
		Iterator<String> i = list.iterator();
		assertEquals("1", i.next());
		assertEquals("2", i.next());
		assertEquals("3", i.next());
	}
	@Test
	void testRemoveAtIndex() {
		list.add("2");
		list.add("yikes");
		list.add("1");
		assertEquals(3,  list.size());
		list.remove(1);
		assertEquals(2,  list.size());
		assertEquals("1",  list.get(0));
		assertEquals("2",  list.get(1));
		
	}
	@Test
	void testRemoveObject() {
		list.add("3");
		list.add("2");
		list.add("1");
		list.add("yikes");
		list.remove(0);
		assertEquals("1", list.get(0));
		assertEquals("2", list.get(1));
		assertEquals("3", list.get(2));
		assertEquals(3,  list.size());
	}
	@Test
	void testSetAtIndex() {
		list.add("3");
		list.add("3");
		list.add("1");
		list.set(1,  "2");
		assertEquals("1", list.get(0));
		assertEquals("2", list.get(1));
		assertEquals("3", list.get(2));
		assertEquals(3,  list.size());
	}
	@Test
	void testSize() {
		list.add("3");
		list.add("2");
		list.add("1");
		assertEquals(3, list.size());
		list.add(1, "1.5");
		assertEquals(4, list.size());
		list.remove(0);
		assertEquals(3, list.size());
		
	}
	@Test
	void testToArray() {
		list.add("3");
		list.add("2");
		list.add("1");
		
		Object [] array = list.toArray();
		
		assertEquals(3, array.length);
		assertEquals("1", array[0]);
		assertEquals("2", array[1]);
		assertEquals("3", array[2]);
		
	}
	@Test
	void testToArraySetByReference() {
		
		list.add("3");
		list.add("2");
		list.add("1");
		
		Object [] array = new Object[list.size()];
		list.toArray(array);
		
		assertEquals(3, array.length);
		assertEquals("1", array[0]);
		assertEquals("2", array[1]);
		assertEquals("3", array[2]);
	}

}
