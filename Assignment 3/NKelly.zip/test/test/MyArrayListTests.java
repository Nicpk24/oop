package test;


import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import utilities.Iterator;
import utilities.MyArrayList;

class MyArrayListTests {
	MyArrayList<Integer> list;

	@BeforeEach
	void setUp() throws Exception {
		list = new MyArrayList<Integer>();
	}


	@AfterEach
	void tearDown() throws Exception {
		list.clear();
		list = null;
	}

	@Test
	void testAdd() {
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(4);
		assertEquals(4, list.size());
	}

	@Test
	void testAddAtIndex() {
		list.add(3);
		list.add(4);
		list.add(0, 1);
		list.add(1, 2);
		assertEquals(1, list.get(0));
		assertEquals(2, list.get(1));
		assertEquals(3, list.get(2));
		assertEquals(4, list.get(3));
	}
	
	@Test
	void testAddAll() {
		MyArrayList<Integer> temp = new MyArrayList<>();
		temp.add(1);
		temp.add(2);
		list.addAll(temp);
		list.add(3);
		assertEquals(1, list.get(0));
		assertEquals(2, list.get(1));
		assertEquals(3, list.get(2));
	}
	
	@Test
	void testClear() {
		list.add(1);
		list.clear();
		list.add(1);
		list.add(2);
		list.add(3);
		assertEquals(3, list.size());
	}
	
	@Test
	void testContains() {
		list.add(42);
		assertTrue(list.contains(42));
	}
	
	@Test
	void testGet() {
		list.add(1);
		list.add(2);
		list.add(3);
		assertEquals(1, list.get(0));
	}
	
	@Test
	void testisEmpty() {
		list.add(1);
		list.clear();
		assertTrue(list.isEmpty());
	}
	
	@Test
	void testIterator() {
		list.add(1);
		list.add(2);
		list.add(3);
		Iterator i = list.iterator();
		
		if (i == null) {
			assertFalse(true);
		}
		
		assertEquals(1, i.next());
		assertEquals(2, i.next());
		assertEquals(3, i.next());
	}
	
	@Test
	void testRemove() {
		list.add(1);
		list.add(2);
		list.add(3);
		list.remove(1);
		assertEquals(1, list.get(0));
		assertEquals(3, list.get(1));
	}
	
	@Test
	void testSet() {
		list.add(1);
		list.set(0, 10);
		assertEquals(10,  list.get(0));
	}
	
	@Test
	void testSize() {
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(4);
		assertEquals(4,  list.size());
	}
	
	@Test
	void testToArray() {
		list.add(1);
		if (list.toArray() == null) {
			assertFalse(true);
		}
		assertEquals(1, list.toArray().length);
	}
}
