package test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import utilities.MyQueue;

class MyQueueTests {
	MyQueue queue;

	@BeforeEach
	void setUp() throws Exception {
		queue = new MyQueue();
	}

	@AfterEach
	void tearDown() throws Exception {
		queue = null;
	}

	@Test
	void testEmpty() {
		queue.push(1);
		queue.push(2);
		queue.pop();
		queue.pop();
		assertEquals(0, queue.size());
	}

	@Test
	void testPeek() {
		queue.push(1);
		assertEquals(1,  queue.peek());
		assertEquals(1,  queue.peek());
		assertEquals(1,  queue.peek());
		assertEquals(1,  queue.size());
	}
	
	@Test
	void testPop() {
		queue.push(1);
		queue.push(2);
		queue.push(3);
		queue.push(4);
		queue.push(5);
		assertEquals(1, queue.pop());
		assertEquals(2, queue.pop());
		assertEquals(3, queue.pop());
		assertEquals(4, queue.pop());
		assertEquals(5, queue.pop());
	}
	
	@Test
	void testPush() {
		queue.push(1);
		queue.push(2);
		queue.push(3);
		queue.push(4);
		queue.push(5);
		assertEquals(5, queue.size());
		assertEquals(1, queue.pop());
	}
	
	@Test
	void testSize() {
		queue.push(1);
		queue.push(2);
		queue.push(3);
		queue.push(4);
		queue.push(5);
		assertEquals(5, queue.size());
	}
}
